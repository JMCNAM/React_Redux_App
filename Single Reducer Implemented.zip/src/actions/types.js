// All action types stored here as unique identifiers. (default not used, many types)
export const EMAIL_CHANGED = 'email_changed';